// style.js
import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
    container: {
        backgroundColor:'green',
        flex: 1,
        
        alignItems: 'center',
    },
});

export default styles;
