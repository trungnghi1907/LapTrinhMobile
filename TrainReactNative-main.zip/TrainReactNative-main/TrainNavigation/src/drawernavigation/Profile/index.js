import React from 'react';
import { View, Button } from 'react-native';
import styles from './style';

const Profile = () => {
  const [count, setCount] = React.useState(0);
  return (
  <View style={styles.container}>
    

  </View>
  );
};

export default Profile;
