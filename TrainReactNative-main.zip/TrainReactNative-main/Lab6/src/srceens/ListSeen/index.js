// UI/index.js
import React, { useState } from 'react';
import { Image, Text, TouchableOpacity, View } from 'react-native';
import styles from './style';
import { useNavigation } from '@react-navigation/native';

// const imageVSblack = require("../../assets/vs_black.png")

// const imageVSblue = require("../../assets/vs_blue.png")

// const imageVSred = require("../../assets/vs_red.png")

// const imageVSilver = require("../../assets/vs_silver.png")


const ListSeenSrceen = () => {


  



  return (




    <View style={styles.container}>

     

        

      
    </View>
  );
};

export default ListSeenSrceen;