import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  containerFirst: {
    paddingTop : 10,
    flex: 1,
    alignItems: 'center',
    backgroundColor: 'white',
  },
 

});

export default styles;
