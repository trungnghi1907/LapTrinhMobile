var khoahoc = [
    'js',
    'php',
    'rb',
];

khoahoc.length = 10;

for(var i = 0;  i < khoahoc.length; ++i){
    console.log(khoahoc[i]);
}